Please file any admin data related issues in our primary data repository:
https://github.com/whosonfirst-data/whosonfirst-data/issues/new.

Helpful information includes:

- Issue Description
- How to Reproduce
- Possible Solution/Data Source
- License of Proposed Data Source
- Related Issues
