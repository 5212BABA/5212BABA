# whosonfirst-data-admin-gn

Who's On First is a gazetteer of places. Not quite _all_ the places in the world but a whole lot of them and, we hope, the kinds of places that we mostly share in common.

This repository contains records for administrative places in **Guinea**.

See this [README](https://github.com/whosonfirst-data/whosonfirst-data/blob/master/README.md) file for a Who's On First project overview, project principles, caveats, and licensing information.

If you see an issue that you'd like to report, please submit it [here](https://github.com/whosonfirst-data/whosonfirst-data/issues/new).

## See also:

* https://github.com/whosonfirst-data/whosonfirst-data/
* https://whosonfirst.org/
* https://whosonfirst.org/download/
